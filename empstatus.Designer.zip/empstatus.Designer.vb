﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class empstatus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(empstatus))
        Me.StorageDataSet = New NTMS.storageDataSet()
        Me.Dealerdata_QueryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Dealerdata_QueryTableAdapter = New NTMS.storageDataSetTableAdapters.dealerdataQueryTableAdapter()
        Me.TableAdapterManager = New NTMS.storageDataSetTableAdapters.TableAdapterManager()
        Me.Dealerdata_QueryBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.Dealerdata_QueryBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TotaltrainedQueryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TotaltrainedQueryTableAdapter = New NTMS.storageDataSetTableAdapters.totaltrainedQueryTableAdapter()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox31 = New System.Windows.Forms.TextBox()
        Me.TextBox32 = New System.Windows.Forms.TextBox()
        Me.TextBox33 = New System.Windows.Forms.TextBox()
        Me.TextBox34 = New System.Windows.Forms.TextBox()
        Me.TextBox35 = New System.Windows.Forms.TextBox()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.TextBox39 = New System.Windows.Forms.TextBox()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.TextBox41 = New System.Windows.Forms.TextBox()
        Me.TextBox42 = New System.Windows.Forms.TextBox()
        Me.TextBox43 = New System.Windows.Forms.TextBox()
        Me.TextBox44 = New System.Windows.Forms.TextBox()
        Me.TextBox45 = New System.Windows.Forms.TextBox()
        Me.TextBox46 = New System.Windows.Forms.TextBox()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.TextBox49 = New System.Windows.Forms.TextBox()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.TextBox51 = New System.Windows.Forms.TextBox()
        Me.TextBox52 = New System.Windows.Forms.TextBox()
        Me.TextBox53 = New System.Windows.Forms.TextBox()
        Me.TextBox54 = New System.Windows.Forms.TextBox()
        Me.TextBox55 = New System.Windows.Forms.TextBox()
        Me.TextBox56 = New System.Windows.Forms.TextBox()
        Me.TextBox57 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TextBox58 = New System.Windows.Forms.TextBox()
        Me.TextBox59 = New System.Windows.Forms.TextBox()
        Me.TextBox60 = New System.Windows.Forms.TextBox()
        Me.DealerdataQueryBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DealerdataQueryTableAdapter = New NTMS.storageDataSetTableAdapters.dealerdataQueryTableAdapter()
        Me.Dealerdata_QueryTableAdapter1 = New NTMS.storageDataSetTableAdapters.dealerdata_QueryTableAdapter()
        CType(Me.StorageDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Dealerdata_QueryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Dealerdata_QueryBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Dealerdata_QueryBindingNavigator.SuspendLayout()
        CType(Me.TotaltrainedQueryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DealerdataQueryBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StorageDataSet
        '
        Me.StorageDataSet.DataSetName = "storageDataSet"
        Me.StorageDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Dealerdata_QueryBindingSource
        '
        Me.Dealerdata_QueryBindingSource.DataMember = "dealerdata Query"
        Me.Dealerdata_QueryBindingSource.DataSource = Me.StorageDataSet
        '
        'Dealerdata_QueryTableAdapter
        '
        Me.Dealerdata_QueryTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Connection = Nothing
        Me.TableAdapterManager.dealer_dataTableAdapter = Nothing
        Me.TableAdapterManager.dealer1TableAdapter = Nothing
        Me.TableAdapterManager.employeeTableAdapter = Nothing
        Me.TableAdapterManager.namesearchTableAdapter = Nothing
        Me.TableAdapterManager.productTableAdapter = Nothing
        Me.TableAdapterManager.testTableAdapter = Nothing
        Me.TableAdapterManager.training_dateTableAdapter = Nothing
        Me.TableAdapterManager.training_statusTableAdapter = Nothing
        Me.TableAdapterManager.tTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = NTMS.storageDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Dealerdata_QueryBindingNavigator
        '
        Me.Dealerdata_QueryBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.Dealerdata_QueryBindingNavigator.BindingSource = Me.Dealerdata_QueryBindingSource
        Me.Dealerdata_QueryBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.Dealerdata_QueryBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.Dealerdata_QueryBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.Dealerdata_QueryBindingNavigatorSaveItem})
        Me.Dealerdata_QueryBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.Dealerdata_QueryBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.Dealerdata_QueryBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.Dealerdata_QueryBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.Dealerdata_QueryBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.Dealerdata_QueryBindingNavigator.Name = "Dealerdata_QueryBindingNavigator"
        Me.Dealerdata_QueryBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.Dealerdata_QueryBindingNavigator.Size = New System.Drawing.Size(841, 25)
        Me.Dealerdata_QueryBindingNavigator.TabIndex = 0
        Me.Dealerdata_QueryBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'Dealerdata_QueryBindingNavigatorSaveItem
        '
        Me.Dealerdata_QueryBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Dealerdata_QueryBindingNavigatorSaveItem.Enabled = False
        Me.Dealerdata_QueryBindingNavigatorSaveItem.Image = CType(resources.GetObject("Dealerdata_QueryBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.Dealerdata_QueryBindingNavigatorSaveItem.Name = "Dealerdata_QueryBindingNavigatorSaveItem"
        Me.Dealerdata_QueryBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.Dealerdata_QueryBindingNavigatorSaveItem.Text = "Save Data"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(26, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "gm"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(26, 96)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(20, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "sm"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(26, 130)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(26, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "asm"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(156, 65)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(36, 20)
        Me.TextBox1.TabIndex = 4
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(156, 96)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(36, 20)
        Me.TextBox2.TabIndex = 5
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(156, 130)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(36, 20)
        Me.TextBox3.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(153, 40)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "planned"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(232, 36)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "onboard"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(327, 36)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(39, 13)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "trained"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(406, 36)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(45, 13)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "balance"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(23, 40)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(43, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "position"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(239, 65)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(39, 20)
        Me.TextBox4.TabIndex = 12
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(240, 96)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(38, 20)
        Me.TextBox5.TabIndex = 13
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(242, 127)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(36, 20)
        Me.TextBox6.TabIndex = 14
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(330, 65)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(36, 20)
        Me.TextBox7.TabIndex = 15
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(329, 96)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(37, 20)
        Me.TextBox8.TabIndex = 16
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(329, 130)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(38, 20)
        Me.TextBox9.TabIndex = 17
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(409, 65)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(34, 20)
        Me.TextBox10.TabIndex = 18
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(410, 96)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(33, 20)
        Me.TextBox11.TabIndex = 19
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(409, 130)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(31, 20)
        Me.TextBox12.TabIndex = 20
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(16, 525)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(56, 20)
        Me.TextBox13.TabIndex = 21
        Me.TextBox13.Text = "GM"
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(78, 525)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(72, 20)
        Me.TextBox14.TabIndex = 22
        Me.TextBox14.Text = "SM"
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(156, 525)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(75, 20)
        Me.TextBox15.TabIndex = 23
        Me.TextBox15.Text = "ASM"
        '
        'TotaltrainedQueryBindingSource
        '
        Me.TotaltrainedQueryBindingSource.DataMember = "totaltrainedQuery"
        Me.TotaltrainedQueryBindingSource.DataSource = Me.StorageDataSet
        '
        'TotaltrainedQueryTableAdapter
        '
        Me.TotaltrainedQueryTableAdapter.ClearBeforeFill = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(23, 166)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(93, 13)
        Me.Label9.TabIndex = 24
        Me.Label9.Text = "TL(SHOWROOM)"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(23, 196)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(93, 13)
        Me.Label10.TabIndex = 25
        Me.Label10.Text = "TL(CORPORATE)"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(23, 232)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(90, 13)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "TL(FIELDSALES)"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(23, 260)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(61, 13)
        Me.Label12.TabIndex = 27
        Me.Label12.Text = "SC(MICRA)"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(26, 287)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(49, 13)
        Me.Label13.TabIndex = 28
        Me.Label13.Text = "SC(CBU)"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(23, 319)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(94, 13)
        Me.Label14.TabIndex = 29
        Me.Label14.Text = "SC(CORPORATE)"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(23, 346)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(10, 13)
        Me.Label15.TabIndex = 30
        Me.Label15.Text = " "
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(23, 373)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(119, 13)
        Me.Label16.TabIndex = 31
        Me.Label16.Text = "DELIVERY INCHARGE"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(26, 403)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(52, 13)
        Me.Label17.TabIndex = 32
        Me.Label17.Text = "OTHERS"
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(156, 163)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(36, 20)
        Me.TextBox16.TabIndex = 33
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(156, 193)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(36, 20)
        Me.TextBox17.TabIndex = 34
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(156, 225)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(36, 20)
        Me.TextBox18.TabIndex = 35
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(156, 254)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(33, 20)
        Me.TextBox19.TabIndex = 36
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(156, 284)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(34, 20)
        Me.TextBox20.TabIndex = 37
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(155, 316)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(34, 20)
        Me.TextBox21.TabIndex = 38
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(156, 342)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(33, 20)
        Me.TextBox22.TabIndex = 39
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(156, 373)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(33, 20)
        Me.TextBox23.TabIndex = 40
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(155, 403)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(33, 20)
        Me.TextBox24.TabIndex = 41
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(242, 163)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(36, 20)
        Me.TextBox25.TabIndex = 42
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(240, 193)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(38, 20)
        Me.TextBox26.TabIndex = 43
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(242, 225)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(36, 20)
        Me.TextBox27.TabIndex = 44
        '
        'TextBox28
        '
        Me.TextBox28.Location = New System.Drawing.Point(242, 253)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(36, 20)
        Me.TextBox28.TabIndex = 45
        '
        'TextBox29
        '
        Me.TextBox29.Location = New System.Drawing.Point(242, 284)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(36, 20)
        Me.TextBox29.TabIndex = 46
        '
        'TextBox30
        '
        Me.TextBox30.Location = New System.Drawing.Point(240, 316)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(37, 20)
        Me.TextBox30.TabIndex = 47
        '
        'TextBox31
        '
        Me.TextBox31.Location = New System.Drawing.Point(240, 342)
        Me.TextBox31.Name = "TextBox31"
        Me.TextBox31.Size = New System.Drawing.Size(38, 20)
        Me.TextBox31.TabIndex = 48
        '
        'TextBox32
        '
        Me.TextBox32.Location = New System.Drawing.Point(241, 373)
        Me.TextBox32.Name = "TextBox32"
        Me.TextBox32.Size = New System.Drawing.Size(37, 20)
        Me.TextBox32.TabIndex = 49
        '
        'TextBox33
        '
        Me.TextBox33.Location = New System.Drawing.Point(239, 403)
        Me.TextBox33.Name = "TextBox33"
        Me.TextBox33.Size = New System.Drawing.Size(39, 20)
        Me.TextBox33.TabIndex = 50
        '
        'TextBox34
        '
        Me.TextBox34.Location = New System.Drawing.Point(330, 159)
        Me.TextBox34.Name = "TextBox34"
        Me.TextBox34.Size = New System.Drawing.Size(36, 20)
        Me.TextBox34.TabIndex = 51
        '
        'TextBox35
        '
        Me.TextBox35.Location = New System.Drawing.Point(328, 189)
        Me.TextBox35.Name = "TextBox35"
        Me.TextBox35.Size = New System.Drawing.Size(38, 20)
        Me.TextBox35.TabIndex = 52
        '
        'TextBox36
        '
        Me.TextBox36.Location = New System.Drawing.Point(329, 225)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(37, 20)
        Me.TextBox36.TabIndex = 53
        '
        'TextBox37
        '
        Me.TextBox37.Location = New System.Drawing.Point(330, 254)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(36, 20)
        Me.TextBox37.TabIndex = 54
        '
        'TextBox38
        '
        Me.TextBox38.Location = New System.Drawing.Point(327, 284)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(39, 20)
        Me.TextBox38.TabIndex = 55
        '
        'TextBox39
        '
        Me.TextBox39.Location = New System.Drawing.Point(329, 316)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(37, 20)
        Me.TextBox39.TabIndex = 56
        '
        'TextBox40
        '
        Me.TextBox40.Location = New System.Drawing.Point(329, 346)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(35, 20)
        Me.TextBox40.TabIndex = 57
        '
        'TextBox41
        '
        Me.TextBox41.Location = New System.Drawing.Point(330, 373)
        Me.TextBox41.Name = "TextBox41"
        Me.TextBox41.Size = New System.Drawing.Size(34, 20)
        Me.TextBox41.TabIndex = 58
        '
        'TextBox42
        '
        Me.TextBox42.Location = New System.Drawing.Point(330, 403)
        Me.TextBox42.Name = "TextBox42"
        Me.TextBox42.Size = New System.Drawing.Size(34, 20)
        Me.TextBox42.TabIndex = 59
        '
        'TextBox43
        '
        Me.TextBox43.Location = New System.Drawing.Point(410, 159)
        Me.TextBox43.Name = "TextBox43"
        Me.TextBox43.Size = New System.Drawing.Size(33, 20)
        Me.TextBox43.TabIndex = 60
        '
        'TextBox44
        '
        Me.TextBox44.Location = New System.Drawing.Point(410, 193)
        Me.TextBox44.Name = "TextBox44"
        Me.TextBox44.Size = New System.Drawing.Size(32, 20)
        Me.TextBox44.TabIndex = 61
        '
        'TextBox45
        '
        Me.TextBox45.Location = New System.Drawing.Point(410, 225)
        Me.TextBox45.Name = "TextBox45"
        Me.TextBox45.Size = New System.Drawing.Size(33, 20)
        Me.TextBox45.TabIndex = 62
        '
        'TextBox46
        '
        Me.TextBox46.Location = New System.Drawing.Point(410, 254)
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Size = New System.Drawing.Size(33, 20)
        Me.TextBox46.TabIndex = 63
        '
        'TextBox47
        '
        Me.TextBox47.Location = New System.Drawing.Point(412, 286)
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(31, 20)
        Me.TextBox47.TabIndex = 64
        '
        'TextBox48
        '
        Me.TextBox48.Location = New System.Drawing.Point(412, 319)
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(31, 20)
        Me.TextBox48.TabIndex = 65
        '
        'TextBox49
        '
        Me.TextBox49.Location = New System.Drawing.Point(409, 349)
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Size = New System.Drawing.Size(33, 20)
        Me.TextBox49.TabIndex = 66
        '
        'TextBox50
        '
        Me.TextBox50.Location = New System.Drawing.Point(409, 375)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(34, 20)
        Me.TextBox50.TabIndex = 67
        '
        'TextBox51
        '
        Me.TextBox51.Location = New System.Drawing.Point(409, 406)
        Me.TextBox51.Name = "TextBox51"
        Me.TextBox51.Size = New System.Drawing.Size(32, 20)
        Me.TextBox51.TabIndex = 68
        '
        'TextBox52
        '
        Me.TextBox52.Location = New System.Drawing.Point(242, 525)
        Me.TextBox52.Name = "TextBox52"
        Me.TextBox52.Size = New System.Drawing.Size(101, 20)
        Me.TextBox52.TabIndex = 69
        Me.TextBox52.Text = "TL(SHOWROOM)"
        '
        'TextBox53
        '
        Me.TextBox53.Location = New System.Drawing.Point(358, 525)
        Me.TextBox53.Name = "TextBox53"
        Me.TextBox53.Size = New System.Drawing.Size(54, 20)
        Me.TextBox53.TabIndex = 70
        Me.TextBox53.Text = "TL(CORPORATE)"
        '
        'TextBox54
        '
        Me.TextBox54.Location = New System.Drawing.Point(429, 525)
        Me.TextBox54.Name = "TextBox54"
        Me.TextBox54.Size = New System.Drawing.Size(70, 20)
        Me.TextBox54.TabIndex = 71
        Me.TextBox54.Text = "TL(FIELDSALES)"
        '
        'TextBox55
        '
        Me.TextBox55.Location = New System.Drawing.Point(19, 494)
        Me.TextBox55.Name = "TextBox55"
        Me.TextBox55.Size = New System.Drawing.Size(32, 20)
        Me.TextBox55.TabIndex = 72
        Me.TextBox55.Text = "SC(MICRA)"
        '
        'TextBox56
        '
        Me.TextBox56.Location = New System.Drawing.Point(78, 494)
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Size = New System.Drawing.Size(29, 20)
        Me.TextBox56.TabIndex = 73
        Me.TextBox56.Text = "SC(CBU)"
        '
        'TextBox57
        '
        Me.TextBox57.Location = New System.Drawing.Point(139, 494)
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Size = New System.Drawing.Size(34, 20)
        Me.TextBox57.TabIndex = 74
        Me.TextBox57.Text = "SC(CORPORATE)"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(26, 349)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(58, 13)
        Me.Label18.TabIndex = 75
        Me.Label18.Text = "HOSTESS"
        '
        'TextBox58
        '
        Me.TextBox58.Location = New System.Drawing.Point(199, 495)
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Size = New System.Drawing.Size(36, 20)
        Me.TextBox58.TabIndex = 76
        Me.TextBox58.Text = "HOSTESS"
        '
        'TextBox59
        '
        Me.TextBox59.Location = New System.Drawing.Point(257, 494)
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Size = New System.Drawing.Size(77, 20)
        Me.TextBox59.TabIndex = 77
        Me.TextBox59.Text = "DELIVERY INCHARGE"
        '
        'TextBox60
        '
        Me.TextBox60.Location = New System.Drawing.Point(357, 495)
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Size = New System.Drawing.Size(40, 20)
        Me.TextBox60.TabIndex = 78
        Me.TextBox60.Text = "OTHERS"
        '
        'DealerdataQueryBindingSource
        '
        Me.DealerdataQueryBindingSource.DataMember = "dealerdataQuery"
        Me.DealerdataQueryBindingSource.DataSource = Me.StorageDataSet
        '
        'DealerdataQueryTableAdapter
        '
        Me.DealerdataQueryTableAdapter.ClearBeforeFill = True
        '
        'Dealerdata_QueryTableAdapter1
        '
        Me.Dealerdata_QueryTableAdapter1.ClearBeforeFill = True
        '
        'empstatus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(841, 565)
        Me.Controls.Add(Me.TextBox60)
        Me.Controls.Add(Me.TextBox59)
        Me.Controls.Add(Me.TextBox58)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.TextBox57)
        Me.Controls.Add(Me.TextBox56)
        Me.Controls.Add(Me.TextBox55)
        Me.Controls.Add(Me.TextBox54)
        Me.Controls.Add(Me.TextBox53)
        Me.Controls.Add(Me.TextBox52)
        Me.Controls.Add(Me.TextBox51)
        Me.Controls.Add(Me.TextBox50)
        Me.Controls.Add(Me.TextBox49)
        Me.Controls.Add(Me.TextBox48)
        Me.Controls.Add(Me.TextBox47)
        Me.Controls.Add(Me.TextBox46)
        Me.Controls.Add(Me.TextBox45)
        Me.Controls.Add(Me.TextBox44)
        Me.Controls.Add(Me.TextBox43)
        Me.Controls.Add(Me.TextBox42)
        Me.Controls.Add(Me.TextBox41)
        Me.Controls.Add(Me.TextBox40)
        Me.Controls.Add(Me.TextBox39)
        Me.Controls.Add(Me.TextBox38)
        Me.Controls.Add(Me.TextBox37)
        Me.Controls.Add(Me.TextBox36)
        Me.Controls.Add(Me.TextBox35)
        Me.Controls.Add(Me.TextBox34)
        Me.Controls.Add(Me.TextBox33)
        Me.Controls.Add(Me.TextBox32)
        Me.Controls.Add(Me.TextBox31)
        Me.Controls.Add(Me.TextBox30)
        Me.Controls.Add(Me.TextBox29)
        Me.Controls.Add(Me.TextBox28)
        Me.Controls.Add(Me.TextBox27)
        Me.Controls.Add(Me.TextBox26)
        Me.Controls.Add(Me.TextBox25)
        Me.Controls.Add(Me.TextBox24)
        Me.Controls.Add(Me.TextBox23)
        Me.Controls.Add(Me.TextBox22)
        Me.Controls.Add(Me.TextBox21)
        Me.Controls.Add(Me.TextBox20)
        Me.Controls.Add(Me.TextBox19)
        Me.Controls.Add(Me.TextBox18)
        Me.Controls.Add(Me.TextBox17)
        Me.Controls.Add(Me.TextBox16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TextBox15)
        Me.Controls.Add(Me.TextBox14)
        Me.Controls.Add(Me.TextBox13)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Dealerdata_QueryBindingNavigator)
        Me.Name = "empstatus"
        Me.Text = "Form1"
        CType(Me.StorageDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Dealerdata_QueryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Dealerdata_QueryBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Dealerdata_QueryBindingNavigator.ResumeLayout(False)
        Me.Dealerdata_QueryBindingNavigator.PerformLayout()
        CType(Me.TotaltrainedQueryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DealerdataQueryBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StorageDataSet As NTMS.storageDataSet
    Friend WithEvents Dealerdata_QueryBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Dealerdata_QueryTableAdapter As NTMS.storageDataSetTableAdapters.dealerdataQueryTableAdapter
    Friend WithEvents TableAdapterManager As NTMS.storageDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Dealerdata_QueryBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Dealerdata_QueryBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TotaltrainedQueryBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TotaltrainedQueryTableAdapter As NTMS.storageDataSetTableAdapters.totaltrainedQueryTableAdapter
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox28 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox29 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox30 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox31 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox32 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox33 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox34 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox35 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox36 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox37 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox38 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox39 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox40 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox43 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox44 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox45 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox46 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox47 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox48 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox49 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox52 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox53 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox54 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox55 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TextBox58 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox59 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox60 As System.Windows.Forms.TextBox
    Friend WithEvents DealerdataQueryBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DealerdataQueryTableAdapter As NTMS.storageDataSetTableAdapters.dealerdataQueryTableAdapter
    Friend WithEvents Dealerdata_QueryTableAdapter1 As NTMS.storageDataSetTableAdapters.dealerdata_QueryTableAdapter
End Class
